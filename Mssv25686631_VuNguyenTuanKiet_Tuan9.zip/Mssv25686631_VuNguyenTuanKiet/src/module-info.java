/**
 * 
 */
/**
 * 
 */
module Mssv25686631_VuNguyenTuanKiet {
	requires jdk.compiler;
}